import SwiftUI
import MapKit

struct SpotMapView: View {
    @Environment(AppEnvironment.self) private var env
    @State private var selected: Spot?
    @State private var position: MapCameraPosition = .userLocation(fallback: .automatic)

    var body: some View {
        NavigationStack {
            ZStack(alignment: .bottom) {
                Map(position: $position) {
                    UserAnnotation()
                    ForEach(env.explorer.all) { s in
                        Annotation(s.name, coordinate: s.coordinate) {
                            Button { withAnimation(.bouncy) { selected = s } } label: {
                                PixelPin(type: s.type, selected: selected?.id == s.id)
                            }
                        }
                    }
                }
                .mapControls { MapUserLocationButton(); MapCompass() }

                if case .loading = env.explorer.state { LoadingView().background(PixelTheme.bg.opacity(0.8)) }
                if case .failed(let key) = env.explorer.state {
                    ErrorView(messageKey: key) { Task { await env.explorer.load(location: env.location.location) } }
                        .background(PixelTheme.bg.opacity(0.9))
                }
                if let s = selected {
                    NavigationLink(value: s) { SpotRow(spot: s, distance: s.distance(from: env.location.location)) }
                        .buttonStyle(.plain).padding()
                        .transition(.move(edge: .bottom).combined(with: .opacity))
                }
            }
            .navigationTitle("map.title").navigationBarTitleDisplayMode(.inline)
            .toolbar { ToolbarItem(placement: .topBarTrailing) { AddSpotButton() } }
            .navigationDestination(for: Spot.self) { SpotDetailView(spot: $0) }
        }
        .task {
            env.location.start()
            await env.explorer.loadIfNeeded(location: env.location.location)
        }
    }
}

struct PixelPin: View {
    let type: SpotType
    let selected: Bool
    var body: some View {
        ZStack {
            PixelRect().fill(PixelTheme.ink).frame(width: 40, height: 40)
            PixelRect().fill(selected ? PixelTheme.green : PixelTheme.accent).frame(width: 32, height: 32)
            Image(systemName: type.icon).font(.system(size: 14, weight: .bold)).foregroundStyle(PixelTheme.midnight)
        }
        .scaleEffect(selected ? 1.3 : 1)
    }
}
